﻿namespace SmartHome
{
    partial class Devices_list
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2ControlBox2 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.m3 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.guna2ToggleSwitch9 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.m2 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.guna2CircleProgressBar3 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.guna2GradientButton6 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton5 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.bunifuProgressBar1 = new Bunifu.Framework.UI.BunifuProgressBar();
            this.label20 = new System.Windows.Forms.Label();
            this.guna2ToggleSwitch8 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.m1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.guna2ToggleSwitch7 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.m11 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.guna2ToggleSwitch6 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.m4 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label16 = new System.Windows.Forms.Label();
            this.lampe_lab = new System.Windows.Forms.Label();
            this.guna2ToggleSwitch5 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.m5 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2ToggleSwitch4 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.m6 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.guna2ToggleSwitch1 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.m7 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2CircleProgressBar1 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2ToggleSwitch2 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.m8 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.guna2ToggleSwitch3 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.guna2GradientButton3 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton4 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2CircleProgressBar2 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.guna2ImageRadioButton2 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.m9 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.guna2GradientButton7 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton8 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2CircleProgressBar4 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label26 = new System.Windows.Forms.Label();
            this.guna2ImageRadioButton6 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.label28 = new System.Windows.Forms.Label();
            this.m10 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label29 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.guna2ToggleSwitch10 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.guna2ComboBox1 = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox8 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2ImageCheckBox1 = new Guna.UI2.WinForms.Guna2ImageCheckBox();
            this.guna2PictureBox7 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox6 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.lampe = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2ImageRadioButton5 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.guna2ImageRadioButton4 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.guna2ImageRadioButton1 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.guna2ImageCheckBox3 = new Guna.UI2.WinForms.Guna2ImageCheckBox();
            this.guna2ImageCheckBox2 = new Guna.UI2.WinForms.Guna2ImageCheckBox();
            this.guna2PictureBox9 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox10 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.flowLayoutPanel1.SuspendLayout();
            this.m3.SuspendLayout();
            this.m2.SuspendLayout();
            this.m1.SuspendLayout();
            this.m11.SuspendLayout();
            this.m4.SuspendLayout();
            this.m5.SuspendLayout();
            this.m6.SuspendLayout();
            this.m7.SuspendLayout();
            this.guna2CircleProgressBar1.SuspendLayout();
            this.m8.SuspendLayout();
            this.guna2CircleProgressBar2.SuspendLayout();
            this.m9.SuspendLayout();
            this.guna2CircleProgressBar4.SuspendLayout();
            this.m10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lampe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox10)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2ControlBox2
            // 
            this.guna2ControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox2.BorderRadius = 3;
            this.guna2ControlBox2.BorderThickness = 1;
            this.guna2ControlBox2.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.guna2ControlBox2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2ControlBox2.HoverState.Parent = this.guna2ControlBox2;
            this.guna2ControlBox2.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox2.Location = new System.Drawing.Point(395, 12);
            this.guna2ControlBox2.Name = "guna2ControlBox2";
            this.guna2ControlBox2.ShadowDecoration.Parent = this.guna2ControlBox2;
            this.guna2ControlBox2.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox2.TabIndex = 27;
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.Animated = true;
            this.guna2ControlBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.BorderRadius = 3;
            this.guna2ControlBox1.BorderThickness = 1;
            this.guna2ControlBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2ControlBox1.HoverState.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox1.Location = new System.Drawing.Point(446, 12);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.ShadowDecoration.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox1.TabIndex = 26;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AllowDrop = true;
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.m3);
            this.flowLayoutPanel1.Controls.Add(this.m2);
            this.flowLayoutPanel1.Controls.Add(this.m1);
            this.flowLayoutPanel1.Controls.Add(this.m11);
            this.flowLayoutPanel1.Controls.Add(this.m4);
            this.flowLayoutPanel1.Controls.Add(this.m5);
            this.flowLayoutPanel1.Controls.Add(this.m6);
            this.flowLayoutPanel1.Controls.Add(this.m7);
            this.flowLayoutPanel1.Controls.Add(this.m8);
            this.flowLayoutPanel1.Controls.Add(this.m9);
            this.flowLayoutPanel1.Controls.Add(this.m10);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 47);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(498, 452);
            this.flowLayoutPanel1.TabIndex = 32;
            this.flowLayoutPanel1.DragDrop += new System.Windows.Forms.DragEventHandler(this.flowLayoutPanel1_DragDrop);
            this.flowLayoutPanel1.DragEnter += new System.Windows.Forms.DragEventHandler(this.flowLayoutPanel1_DragEnter);
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // m3
            // 
            this.m3.BackColor = System.Drawing.Color.Transparent;
            this.m3.Controls.Add(this.label23);
            this.m3.Controls.Add(this.label21);
            this.m3.Controls.Add(this.label22);
            this.m3.Controls.Add(this.guna2ToggleSwitch9);
            this.m3.Controls.Add(this.guna2PictureBox8);
            this.m3.FillColor = System.Drawing.Color.White;
            this.m3.Location = new System.Drawing.Point(3, 3);
            this.m3.Name = "m3";
            this.m3.Radius = 12;
            this.m3.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m3.ShadowDepth = 70;
            this.m3.Size = new System.Drawing.Size(150, 144);
            this.m3.TabIndex = 40;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(13, 88);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(0, 14);
            this.label23.TabIndex = 17;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(29, 113);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(28, 14);
            this.label21.TabIndex = 16;
            this.label21.Text = "Wifi";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(97, 54);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(27, 14);
            this.label22.TabIndex = 2;
            this.label22.Text = "OFF";
            // 
            // guna2ToggleSwitch9
            // 
            this.guna2ToggleSwitch9.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch9.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch9.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch9.CheckedState.Parent = this.guna2ToggleSwitch9;
            this.guna2ToggleSwitch9.Location = new System.Drawing.Point(90, 22);
            this.guna2ToggleSwitch9.Name = "guna2ToggleSwitch9";
            this.guna2ToggleSwitch9.ShadowDecoration.Parent = this.guna2ToggleSwitch9;
            this.guna2ToggleSwitch9.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch9.TabIndex = 15;
            this.guna2ToggleSwitch9.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch9.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch9.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch9.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch9.UncheckedState.Parent = this.guna2ToggleSwitch9;
            this.guna2ToggleSwitch9.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch9_CheckedChanged_1);
            // 
            // m2
            // 
            this.m2.BackColor = System.Drawing.Color.Transparent;
            this.m2.Controls.Add(this.guna2CircleProgressBar3);
            this.m2.Controls.Add(this.guna2ImageCheckBox1);
            this.m2.Controls.Add(this.guna2GradientButton6);
            this.m2.Controls.Add(this.guna2GradientButton5);
            this.m2.Controls.Add(this.bunifuProgressBar1);
            this.m2.Controls.Add(this.label20);
            this.m2.Controls.Add(this.guna2ToggleSwitch8);
            this.m2.Controls.Add(this.guna2PictureBox7);
            this.m2.FillColor = System.Drawing.Color.White;
            this.m2.Location = new System.Drawing.Point(159, 3);
            this.m2.Name = "m2";
            this.m2.Radius = 12;
            this.m2.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m2.ShadowDepth = 70;
            this.m2.Size = new System.Drawing.Size(310, 144);
            this.m2.TabIndex = 41;
            // 
            // guna2CircleProgressBar3
            // 
            this.guna2CircleProgressBar3.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleProgressBar3.FillThickness = 5;
            this.guna2CircleProgressBar3.Location = new System.Drawing.Point(198, 18);
            this.guna2CircleProgressBar3.Maximum = 31;
            this.guna2CircleProgressBar3.Name = "guna2CircleProgressBar3";
            this.guna2CircleProgressBar3.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2CircleProgressBar3.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2CircleProgressBar3.ProgressEndCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar3.ProgressStartCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar3.ProgressThickness = 5;
            this.guna2CircleProgressBar3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar3.ShadowDecoration.Parent = this.guna2CircleProgressBar3;
            this.guna2CircleProgressBar3.Size = new System.Drawing.Size(41, 41);
            this.guna2CircleProgressBar3.TabIndex = 26;
            this.guna2CircleProgressBar3.UseTransparentBackground = true;
            // 
            // guna2GradientButton6
            // 
            this.guna2GradientButton6.BorderRadius = 6;
            this.guna2GradientButton6.CheckedState.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton6.CustomImages.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Enabled = false;
            this.guna2GradientButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton6.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton6.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton6.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton6.HoverState.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Location = new System.Drawing.Point(250, 32);
            this.guna2GradientButton6.Name = "guna2GradientButton6";
            this.guna2GradientButton6.ShadowDecoration.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Size = new System.Drawing.Size(28, 17);
            this.guna2GradientButton6.TabIndex = 25;
            this.guna2GradientButton6.Text = "+";
            this.guna2GradientButton6.Click += new System.EventHandler(this.guna2GradientButton6_Click_1);
            // 
            // guna2GradientButton5
            // 
            this.guna2GradientButton5.BorderRadius = 6;
            this.guna2GradientButton5.CheckedState.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton5.CustomImages.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Enabled = false;
            this.guna2GradientButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton5.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton5.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton5.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton5.HoverState.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Location = new System.Drawing.Point(158, 32);
            this.guna2GradientButton5.Name = "guna2GradientButton5";
            this.guna2GradientButton5.ShadowDecoration.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Size = new System.Drawing.Size(28, 17);
            this.guna2GradientButton5.TabIndex = 25;
            this.guna2GradientButton5.Text = "-";
            this.guna2GradientButton5.Click += new System.EventHandler(this.guna2GradientButton5_Click_1);
            // 
            // bunifuProgressBar1
            // 
            this.bunifuProgressBar1.BackColor = System.Drawing.Color.Silver;
            this.bunifuProgressBar1.BorderRadius = 5;
            this.bunifuProgressBar1.Location = new System.Drawing.Point(11, 108);
            this.bunifuProgressBar1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuProgressBar1.MaximumValue = 1000;
            this.bunifuProgressBar1.Name = "bunifuProgressBar1";
            this.bunifuProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.bunifuProgressBar1.Size = new System.Drawing.Size(267, 11);
            this.bunifuProgressBar1.TabIndex = 17;
            this.bunifuProgressBar1.Value = 0;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(128, 122);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(43, 14);
            this.label20.TabIndex = 16;
            this.label20.Text = "Woofer";
            // 
            // guna2ToggleSwitch8
            // 
            this.guna2ToggleSwitch8.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch8.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch8.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch8.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch8.CheckedState.Parent = this.guna2ToggleSwitch8;
            this.guna2ToggleSwitch8.Location = new System.Drawing.Point(90, 22);
            this.guna2ToggleSwitch8.Name = "guna2ToggleSwitch8";
            this.guna2ToggleSwitch8.ShadowDecoration.Parent = this.guna2ToggleSwitch8;
            this.guna2ToggleSwitch8.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch8.TabIndex = 15;
            this.guna2ToggleSwitch8.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch8.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch8.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch8.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch8.UncheckedState.Parent = this.guna2ToggleSwitch8;
            this.guna2ToggleSwitch8.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch8_CheckedChanged_1);
            // 
            // m1
            // 
            this.m1.BackColor = System.Drawing.Color.Transparent;
            this.m1.Controls.Add(this.label18);
            this.m1.Controls.Add(this.label19);
            this.m1.Controls.Add(this.guna2ToggleSwitch7);
            this.m1.Controls.Add(this.guna2PictureBox6);
            this.m1.FillColor = System.Drawing.Color.White;
            this.m1.Location = new System.Drawing.Point(3, 153);
            this.m1.Name = "m1";
            this.m1.Radius = 12;
            this.m1.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m1.ShadowDepth = 70;
            this.m1.Size = new System.Drawing.Size(150, 144);
            this.m1.TabIndex = 39;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(29, 113);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 14);
            this.label18.TabIndex = 16;
            this.label18.Text = "Sedar Rideau";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(97, 54);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(27, 14);
            this.label19.TabIndex = 2;
            this.label19.Text = "OFF";
            // 
            // guna2ToggleSwitch7
            // 
            this.guna2ToggleSwitch7.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch7.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch7.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch7.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch7.CheckedState.Parent = this.guna2ToggleSwitch7;
            this.guna2ToggleSwitch7.Location = new System.Drawing.Point(90, 22);
            this.guna2ToggleSwitch7.Name = "guna2ToggleSwitch7";
            this.guna2ToggleSwitch7.ShadowDecoration.Parent = this.guna2ToggleSwitch7;
            this.guna2ToggleSwitch7.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch7.TabIndex = 15;
            this.guna2ToggleSwitch7.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch7.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch7.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch7.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch7.UncheckedState.Parent = this.guna2ToggleSwitch7;
            this.guna2ToggleSwitch7.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch7_CheckedChanged_1);
            // 
            // m11
            // 
            this.m11.BackColor = System.Drawing.Color.Transparent;
            this.m11.Controls.Add(this.label3);
            this.m11.Controls.Add(this.label17);
            this.m11.Controls.Add(this.guna2ToggleSwitch6);
            this.m11.Controls.Add(this.guna2PictureBox5);
            this.m11.FillColor = System.Drawing.Color.White;
            this.m11.Location = new System.Drawing.Point(159, 153);
            this.m11.Name = "m11";
            this.m11.Radius = 12;
            this.m11.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m11.ShadowDepth = 70;
            this.m11.Size = new System.Drawing.Size(150, 144);
            this.m11.TabIndex = 36;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 14);
            this.label3.TabIndex = 16;
            this.label3.Text = "Robot Aspirateur";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(97, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(27, 14);
            this.label17.TabIndex = 2;
            this.label17.Text = "OFF";
            // 
            // guna2ToggleSwitch6
            // 
            this.guna2ToggleSwitch6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch6.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch6.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch6.CheckedState.Parent = this.guna2ToggleSwitch6;
            this.guna2ToggleSwitch6.Location = new System.Drawing.Point(90, 22);
            this.guna2ToggleSwitch6.Name = "guna2ToggleSwitch6";
            this.guna2ToggleSwitch6.ShadowDecoration.Parent = this.guna2ToggleSwitch6;
            this.guna2ToggleSwitch6.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch6.TabIndex = 15;
            this.guna2ToggleSwitch6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch6.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch6.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch6.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch6.UncheckedState.Parent = this.guna2ToggleSwitch6;
            this.guna2ToggleSwitch6.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch6_CheckedChanged_1);
            // 
            // m4
            // 
            this.m4.BackColor = System.Drawing.Color.Transparent;
            this.m4.Controls.Add(this.label16);
            this.m4.Controls.Add(this.lampe_lab);
            this.m4.Controls.Add(this.guna2ToggleSwitch5);
            this.m4.Controls.Add(this.lampe);
            this.m4.FillColor = System.Drawing.Color.White;
            this.m4.Location = new System.Drawing.Point(315, 153);
            this.m4.Name = "m4";
            this.m4.Radius = 12;
            this.m4.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m4.ShadowDepth = 70;
            this.m4.Size = new System.Drawing.Size(147, 144);
            this.m4.TabIndex = 33;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(18, 109);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 14);
            this.label16.TabIndex = 16;
            this.label16.Text = "Lampe du bureau";
            // 
            // lampe_lab
            // 
            this.lampe_lab.AutoSize = true;
            this.lampe_lab.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lampe_lab.Location = new System.Drawing.Point(97, 54);
            this.lampe_lab.Name = "lampe_lab";
            this.lampe_lab.Size = new System.Drawing.Size(27, 14);
            this.lampe_lab.TabIndex = 2;
            this.lampe_lab.Text = "OFF";
            // 
            // guna2ToggleSwitch5
            // 
            this.guna2ToggleSwitch5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch5.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch5.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch5.CheckedState.Parent = this.guna2ToggleSwitch5;
            this.guna2ToggleSwitch5.Location = new System.Drawing.Point(90, 22);
            this.guna2ToggleSwitch5.Name = "guna2ToggleSwitch5";
            this.guna2ToggleSwitch5.ShadowDecoration.Parent = this.guna2ToggleSwitch5;
            this.guna2ToggleSwitch5.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch5.TabIndex = 15;
            this.guna2ToggleSwitch5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch5.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch5.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch5.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch5.UncheckedState.Parent = this.guna2ToggleSwitch5;
            this.guna2ToggleSwitch5.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch5_CheckedChanged_1);
            // 
            // m5
            // 
            this.m5.BackColor = System.Drawing.Color.Transparent;
            this.m5.Controls.Add(this.label1);
            this.m5.Controls.Add(this.label2);
            this.m5.Controls.Add(this.guna2ToggleSwitch4);
            this.m5.Controls.Add(this.guna2PictureBox4);
            this.m5.FillColor = System.Drawing.Color.White;
            this.m5.Location = new System.Drawing.Point(3, 303);
            this.m5.Name = "m5";
            this.m5.Radius = 12;
            this.m5.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m5.ShadowDepth = 70;
            this.m5.Size = new System.Drawing.Size(150, 144);
            this.m5.TabIndex = 34;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(58, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 14);
            this.label1.TabIndex = 16;
            this.label1.Text = "Porte";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(97, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 14);
            this.label2.TabIndex = 2;
            this.label2.Text = "OFF";
            // 
            // guna2ToggleSwitch4
            // 
            this.guna2ToggleSwitch4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch4.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch4.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch4.CheckedState.Parent = this.guna2ToggleSwitch4;
            this.guna2ToggleSwitch4.Location = new System.Drawing.Point(90, 22);
            this.guna2ToggleSwitch4.Name = "guna2ToggleSwitch4";
            this.guna2ToggleSwitch4.ShadowDecoration.Parent = this.guna2ToggleSwitch4;
            this.guna2ToggleSwitch4.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch4.TabIndex = 15;
            this.guna2ToggleSwitch4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch4.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch4.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch4.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch4.UncheckedState.Parent = this.guna2ToggleSwitch4;
            this.guna2ToggleSwitch4.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch4_CheckedChanged_1);
            // 
            // m6
            // 
            this.m6.BackColor = System.Drawing.Color.Transparent;
            this.m6.Controls.Add(this.label14);
            this.m6.Controls.Add(this.label15);
            this.m6.Controls.Add(this.guna2ToggleSwitch1);
            this.m6.Controls.Add(this.guna2PictureBox1);
            this.m6.FillColor = System.Drawing.Color.White;
            this.m6.Location = new System.Drawing.Point(159, 303);
            this.m6.Name = "m6";
            this.m6.Radius = 12;
            this.m6.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m6.ShadowDepth = 70;
            this.m6.Size = new System.Drawing.Size(150, 144);
            this.m6.TabIndex = 37;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(54, 122);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 14);
            this.label14.TabIndex = 16;
            this.label14.Text = "Camera";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(97, 54);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(27, 14);
            this.label15.TabIndex = 2;
            this.label15.Text = "OFF";
            // 
            // guna2ToggleSwitch1
            // 
            this.guna2ToggleSwitch1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch1.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch1.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch1.CheckedState.Parent = this.guna2ToggleSwitch1;
            this.guna2ToggleSwitch1.Location = new System.Drawing.Point(90, 22);
            this.guna2ToggleSwitch1.Name = "guna2ToggleSwitch1";
            this.guna2ToggleSwitch1.ShadowDecoration.Parent = this.guna2ToggleSwitch1;
            this.guna2ToggleSwitch1.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch1.TabIndex = 15;
            this.guna2ToggleSwitch1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch1.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch1.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch1.UncheckedState.Parent = this.guna2ToggleSwitch1;
            this.guna2ToggleSwitch1.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch1_CheckedChanged_1);
            // 
            // m7
            // 
            this.m7.BackColor = System.Drawing.Color.Transparent;
            this.m7.Controls.Add(this.label6);
            this.m7.Controls.Add(this.guna2GradientButton2);
            this.m7.Controls.Add(this.guna2GradientButton1);
            this.m7.Controls.Add(this.guna2CircleProgressBar1);
            this.m7.Controls.Add(this.label4);
            this.m7.Controls.Add(this.label5);
            this.m7.Controls.Add(this.guna2ToggleSwitch2);
            this.m7.Controls.Add(this.guna2PictureBox2);
            this.m7.FillColor = System.Drawing.Color.White;
            this.m7.Location = new System.Drawing.Point(315, 303);
            this.m7.Name = "m7";
            this.m7.Radius = 12;
            this.m7.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m7.ShadowDepth = 70;
            this.m7.Size = new System.Drawing.Size(150, 144);
            this.m7.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 14);
            this.label6.TabIndex = 24;
            this.label6.Text = "Volume :";
            // 
            // guna2GradientButton2
            // 
            this.guna2GradientButton2.BorderRadius = 6;
            this.guna2GradientButton2.CheckedState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton2.CustomImages.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Enabled = false;
            this.guna2GradientButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton2.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton2.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton2.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton2.HoverState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Location = new System.Drawing.Point(21, 95);
            this.guna2GradientButton2.Name = "guna2GradientButton2";
            this.guna2GradientButton2.ShadowDecoration.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Size = new System.Drawing.Size(28, 17);
            this.guna2GradientButton2.TabIndex = 23;
            this.guna2GradientButton2.Text = "-";
            this.guna2GradientButton2.Click += new System.EventHandler(this.guna2GradientButton2_Click_1);
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.BorderRadius = 6;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Enabled = false;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton1.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(101, 95);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(28, 17);
            this.guna2GradientButton1.TabIndex = 22;
            this.guna2GradientButton1.Text = "+";
            this.guna2GradientButton1.Click += new System.EventHandler(this.guna2GradientButton1_Click_1);
            // 
            // guna2CircleProgressBar1
            // 
            this.guna2CircleProgressBar1.Animated = true;
            this.guna2CircleProgressBar1.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleProgressBar1.Controls.Add(this.label8);
            this.guna2CircleProgressBar1.Controls.Add(this.label7);
            this.guna2CircleProgressBar1.FillThickness = 5;
            this.guna2CircleProgressBar1.Location = new System.Drawing.Point(54, 82);
            this.guna2CircleProgressBar1.Maximum = 31;
            this.guna2CircleProgressBar1.Name = "guna2CircleProgressBar1";
            this.guna2CircleProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2CircleProgressBar1.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2CircleProgressBar1.ProgressEndCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar1.ProgressStartCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar1.ProgressThickness = 5;
            this.guna2CircleProgressBar1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar1.ShadowDecoration.Parent = this.guna2CircleProgressBar1;
            this.guna2CircleProgressBar1.Size = new System.Drawing.Size(41, 41);
            this.guna2CircleProgressBar1.TabIndex = 20;
            this.guna2CircleProgressBar1.UseTransparentBackground = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(11, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 14);
            this.label8.TabIndex = 25;
            this.label8.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label7.Location = new System.Drawing.Point(40, 55);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 21);
            this.label7.TabIndex = 21;
            this.label7.Text = "+24 C";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(48, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 14);
            this.label4.TabIndex = 16;
            this.label4.Text = "Samsung";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(97, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 14);
            this.label5.TabIndex = 2;
            this.label5.Text = "OFF";
            // 
            // guna2ToggleSwitch2
            // 
            this.guna2ToggleSwitch2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch2.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch2.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch2.CheckedState.Parent = this.guna2ToggleSwitch2;
            this.guna2ToggleSwitch2.Location = new System.Drawing.Point(90, 22);
            this.guna2ToggleSwitch2.Name = "guna2ToggleSwitch2";
            this.guna2ToggleSwitch2.ShadowDecoration.Parent = this.guna2ToggleSwitch2;
            this.guna2ToggleSwitch2.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch2.TabIndex = 15;
            this.guna2ToggleSwitch2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch2.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch2.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch2.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch2.UncheckedState.Parent = this.guna2ToggleSwitch2;
            this.guna2ToggleSwitch2.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch2_CheckedChanged_1);
            // 
            // m8
            // 
            this.m8.BackColor = System.Drawing.Color.Transparent;
            this.m8.Controls.Add(this.guna2ToggleSwitch3);
            this.m8.Controls.Add(this.guna2PictureBox3);
            this.m8.Controls.Add(this.guna2GradientButton3);
            this.m8.Controls.Add(this.guna2GradientButton4);
            this.m8.Controls.Add(this.label9);
            this.m8.Controls.Add(this.guna2CircleProgressBar2);
            this.m8.Controls.Add(this.guna2ImageRadioButton5);
            this.m8.Controls.Add(this.label11);
            this.m8.Controls.Add(this.guna2ImageRadioButton2);
            this.m8.Controls.Add(this.label12);
            this.m8.Controls.Add(this.guna2ImageRadioButton4);
            this.m8.Controls.Add(this.label13);
            this.m8.Controls.Add(this.guna2ImageRadioButton1);
            this.m8.FillColor = System.Drawing.Color.White;
            this.m8.Location = new System.Drawing.Point(3, 453);
            this.m8.Name = "m8";
            this.m8.Radius = 12;
            this.m8.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m8.ShadowDepth = 50;
            this.m8.ShadowShift = 6;
            this.m8.Size = new System.Drawing.Size(459, 144);
            this.m8.TabIndex = 38;
            // 
            // guna2ToggleSwitch3
            // 
            this.guna2ToggleSwitch3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch3.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.CheckedState.Parent = this.guna2ToggleSwitch3;
            this.guna2ToggleSwitch3.Location = new System.Drawing.Point(97, 20);
            this.guna2ToggleSwitch3.Name = "guna2ToggleSwitch3";
            this.guna2ToggleSwitch3.ShadowDecoration.Parent = this.guna2ToggleSwitch3;
            this.guna2ToggleSwitch3.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch3.TabIndex = 25;
            this.guna2ToggleSwitch3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch3.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch3.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.UncheckedState.Parent = this.guna2ToggleSwitch3;
            this.guna2ToggleSwitch3.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch3_CheckedChanged_1);
            // 
            // guna2GradientButton3
            // 
            this.guna2GradientButton3.BorderRadius = 6;
            this.guna2GradientButton3.CheckedState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton3.CustomImages.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Enabled = false;
            this.guna2GradientButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton3.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton3.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton3.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton3.HoverState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Location = new System.Drawing.Point(208, 71);
            this.guna2GradientButton3.Name = "guna2GradientButton3";
            this.guna2GradientButton3.ShadowDecoration.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Size = new System.Drawing.Size(45, 26);
            this.guna2GradientButton3.TabIndex = 22;
            this.guna2GradientButton3.Text = "-";
            this.guna2GradientButton3.Click += new System.EventHandler(this.guna2GradientButton3_Click_1);
            // 
            // guna2GradientButton4
            // 
            this.guna2GradientButton4.BorderRadius = 6;
            this.guna2GradientButton4.CheckedState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton4.CustomImages.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Enabled = false;
            this.guna2GradientButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton4.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton4.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton4.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton4.HoverState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Location = new System.Drawing.Point(388, 71);
            this.guna2GradientButton4.Name = "guna2GradientButton4";
            this.guna2GradientButton4.ShadowDecoration.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Size = new System.Drawing.Size(45, 26);
            this.guna2GradientButton4.TabIndex = 21;
            this.guna2GradientButton4.Text = "+";
            this.guna2GradientButton4.Click += new System.EventHandler(this.guna2GradientButton4_Click_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label9.Location = new System.Drawing.Point(145, 114);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 21);
            this.label9.TabIndex = 20;
            this.label9.Text = "Auto";
            // 
            // guna2CircleProgressBar2
            // 
            this.guna2CircleProgressBar2.Animated = true;
            this.guna2CircleProgressBar2.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleProgressBar2.Controls.Add(this.label10);
            this.guna2CircleProgressBar2.FillThickness = 15;
            this.guna2CircleProgressBar2.Location = new System.Drawing.Point(272, 28);
            this.guna2CircleProgressBar2.Maximum = 31;
            this.guna2CircleProgressBar2.Name = "guna2CircleProgressBar2";
            this.guna2CircleProgressBar2.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2CircleProgressBar2.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2CircleProgressBar2.ProgressEndCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar2.ProgressStartCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar2.ProgressThickness = 15;
            this.guna2CircleProgressBar2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar2.ShadowDecoration.Parent = this.guna2CircleProgressBar2;
            this.guna2CircleProgressBar2.Size = new System.Drawing.Size(100, 100);
            this.guna2CircleProgressBar2.TabIndex = 19;
            this.guna2CircleProgressBar2.UseTransparentBackground = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label10.Location = new System.Drawing.Point(26, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 21);
            this.label10.TabIndex = 21;
            this.label10.Text = "+0 C";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label11.Location = new System.Drawing.Point(85, 114);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 21);
            this.label11.TabIndex = 19;
            this.label11.Text = "Heat";
            // 
            // guna2ImageRadioButton2
            // 
            this.guna2ImageRadioButton2.CheckedState.Parent = this.guna2ImageRadioButton2;
            this.guna2ImageRadioButton2.HoverState.Parent = this.guna2ImageRadioButton2;
            this.guna2ImageRadioButton2.Location = new System.Drawing.Point(72, 342);
            this.guna2ImageRadioButton2.Name = "guna2ImageRadioButton2";
            this.guna2ImageRadioButton2.PressedState.Parent = this.guna2ImageRadioButton2;
            this.guna2ImageRadioButton2.Size = new System.Drawing.Size(75, 23);
            this.guna2ImageRadioButton2.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label12.Location = new System.Drawing.Point(141, 4);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(155, 21);
            this.label12.TabIndex = 2;
            this.label12.Text = "Room temperature";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label13.Location = new System.Drawing.Point(24, 114);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 21);
            this.label13.TabIndex = 18;
            this.label13.Text = "Cool";
            // 
            // m9
            // 
            this.m9.BackColor = System.Drawing.Color.Transparent;
            this.m9.Controls.Add(this.guna2ImageCheckBox3);
            this.m9.Controls.Add(this.guna2ImageCheckBox2);
            this.m9.Controls.Add(this.guna2PictureBox9);
            this.m9.Controls.Add(this.guna2GradientButton7);
            this.m9.Controls.Add(this.guna2GradientButton8);
            this.m9.Controls.Add(this.guna2CircleProgressBar4);
            this.m9.Controls.Add(this.guna2ImageRadioButton6);
            this.m9.Controls.Add(this.label28);
            this.m9.FillColor = System.Drawing.Color.White;
            this.m9.Location = new System.Drawing.Point(3, 603);
            this.m9.Name = "m9";
            this.m9.Radius = 12;
            this.m9.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m9.ShadowDepth = 50;
            this.m9.ShadowShift = 6;
            this.m9.Size = new System.Drawing.Size(459, 144);
            this.m9.TabIndex = 39;
            this.m9.Paint += new System.Windows.Forms.PaintEventHandler(this.m9_Paint);
            // 
            // guna2GradientButton7
            // 
            this.guna2GradientButton7.BorderRadius = 6;
            this.guna2GradientButton7.CheckedState.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton7.CustomImages.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton7.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton7.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton7.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton7.HoverState.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Location = new System.Drawing.Point(208, 71);
            this.guna2GradientButton7.Name = "guna2GradientButton7";
            this.guna2GradientButton7.ShadowDecoration.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Size = new System.Drawing.Size(45, 26);
            this.guna2GradientButton7.TabIndex = 22;
            this.guna2GradientButton7.Text = "-";
            this.guna2GradientButton7.Click += new System.EventHandler(this.guna2GradientButton7_Click);
            // 
            // guna2GradientButton8
            // 
            this.guna2GradientButton8.BorderRadius = 6;
            this.guna2GradientButton8.CheckedState.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton8.CustomImages.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton8.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton8.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton8.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton8.HoverState.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Location = new System.Drawing.Point(388, 71);
            this.guna2GradientButton8.Name = "guna2GradientButton8";
            this.guna2GradientButton8.ShadowDecoration.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Size = new System.Drawing.Size(45, 26);
            this.guna2GradientButton8.TabIndex = 21;
            this.guna2GradientButton8.Text = "+";
            this.guna2GradientButton8.Click += new System.EventHandler(this.guna2GradientButton8_Click);
            // 
            // guna2CircleProgressBar4
            // 
            this.guna2CircleProgressBar4.Animated = true;
            this.guna2CircleProgressBar4.AnimationSpeed = 0.3F;
            this.guna2CircleProgressBar4.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleProgressBar4.Controls.Add(this.label26);
            this.guna2CircleProgressBar4.FillThickness = 15;
            this.guna2CircleProgressBar4.Location = new System.Drawing.Point(272, 28);
            this.guna2CircleProgressBar4.Maximum = 31;
            this.guna2CircleProgressBar4.Name = "guna2CircleProgressBar4";
            this.guna2CircleProgressBar4.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2CircleProgressBar4.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2CircleProgressBar4.ProgressEndCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar4.ProgressStartCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar4.ProgressThickness = 15;
            this.guna2CircleProgressBar4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar4.ShadowDecoration.Parent = this.guna2CircleProgressBar4;
            this.guna2CircleProgressBar4.Size = new System.Drawing.Size(100, 100);
            this.guna2CircleProgressBar4.TabIndex = 19;
            this.guna2CircleProgressBar4.UseTransparentBackground = true;
            this.guna2CircleProgressBar4.ValueChanged += new System.EventHandler(this.guna2CircleProgressBar4_ValueChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label26.Location = new System.Drawing.Point(27, 40);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(44, 21);
            this.label26.TabIndex = 21;
            this.label26.Text = "+0 C";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // guna2ImageRadioButton6
            // 
            this.guna2ImageRadioButton6.CheckedState.Parent = this.guna2ImageRadioButton6;
            this.guna2ImageRadioButton6.HoverState.Parent = this.guna2ImageRadioButton6;
            this.guna2ImageRadioButton6.Location = new System.Drawing.Point(72, 342);
            this.guna2ImageRadioButton6.Name = "guna2ImageRadioButton6";
            this.guna2ImageRadioButton6.PressedState.Parent = this.guna2ImageRadioButton6;
            this.guna2ImageRadioButton6.Size = new System.Drawing.Size(75, 23);
            this.guna2ImageRadioButton6.TabIndex = 17;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label28.Location = new System.Drawing.Point(27, 99);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 21);
            this.label28.TabIndex = 2;
            this.label28.Text = "Fridge";
            // 
            // m10
            // 
            this.m10.BackColor = System.Drawing.Color.Transparent;
            this.m10.Controls.Add(this.label29);
            this.m10.Controls.Add(this.label25);
            this.m10.Controls.Add(this.label27);
            this.m10.Controls.Add(this.guna2ToggleSwitch10);
            this.m10.Controls.Add(this.guna2PictureBox10);
            this.m10.FillColor = System.Drawing.Color.White;
            this.m10.Location = new System.Drawing.Point(3, 753);
            this.m10.Name = "m10";
            this.m10.Radius = 12;
            this.m10.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m10.ShadowDepth = 70;
            this.m10.Size = new System.Drawing.Size(150, 144);
            this.m10.TabIndex = 42;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(81, 68);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(27, 14);
            this.label29.TabIndex = 17;
            this.label29.Text = "OFF";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(34, 114);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(75, 14);
            this.label25.TabIndex = 16;
            this.label25.Text = "Coffee Maker";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(82, 54);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(27, 14);
            this.label27.TabIndex = 2;
            this.label27.Text = "OFF";
            // 
            // guna2ToggleSwitch10
            // 
            this.guna2ToggleSwitch10.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch10.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch10.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch10.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch10.CheckedState.Parent = this.guna2ToggleSwitch10;
            this.guna2ToggleSwitch10.Location = new System.Drawing.Point(90, 22);
            this.guna2ToggleSwitch10.Name = "guna2ToggleSwitch10";
            this.guna2ToggleSwitch10.ShadowDecoration.Parent = this.guna2ToggleSwitch10;
            this.guna2ToggleSwitch10.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch10.TabIndex = 15;
            this.guna2ToggleSwitch10.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch10.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch10.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch10.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch10.UncheckedState.Parent = this.guna2ToggleSwitch10;
            this.guna2ToggleSwitch10.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch10_CheckedChanged);
            // 
            // guna2ComboBox1
            // 
            this.guna2ComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox1.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox1.FocusedState.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2ComboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.guna2ComboBox1.FormattingEnabled = true;
            this.guna2ComboBox1.HoverState.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.ItemHeight = 30;
            this.guna2ComboBox1.ItemsAppearance.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Location = new System.Drawing.Point(22, 592);
            this.guna2ComboBox1.Name = "guna2ComboBox1";
            this.guna2ComboBox1.ShadowDecoration.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Size = new System.Drawing.Size(239, 36);
            this.guna2ComboBox1.TabIndex = 33;
            // 
            // guna2Button1
            // 
            this.guna2Button1.Animated = true;
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BorderRadius = 21;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2Button1.Font = new System.Drawing.Font("Montserrat Medium", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(292, 587);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(170, 45);
            this.guna2Button1.TabIndex = 34;
            this.guna2Button1.Text = "Ajouter";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // guna2PictureBox8
            // 
            this.guna2PictureBox8.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox8.Image = global::SmartHome.Properties.Resources.wifi;
            this.guna2PictureBox8.Location = new System.Drawing.Point(7, 13);
            this.guna2PictureBox8.Name = "guna2PictureBox8";
            this.guna2PictureBox8.ShadowDecoration.Parent = this.guna2PictureBox8;
            this.guna2PictureBox8.Size = new System.Drawing.Size(65, 67);
            this.guna2PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox8.TabIndex = 0;
            this.guna2PictureBox8.TabStop = false;
            // 
            // guna2ImageCheckBox1
            // 
            this.guna2ImageCheckBox1.CheckedState.Image = global::SmartHome.Properties.Resources.pause;
            this.guna2ImageCheckBox1.CheckedState.Parent = this.guna2ImageCheckBox1;
            this.guna2ImageCheckBox1.HoverState.Parent = this.guna2ImageCheckBox1;
            this.guna2ImageCheckBox1.Image = global::SmartHome.Properties.Resources.resume;
            this.guna2ImageCheckBox1.Location = new System.Drawing.Point(111, 79);
            this.guna2ImageCheckBox1.Name = "guna2ImageCheckBox1";
            this.guna2ImageCheckBox1.PressedState.Parent = this.guna2ImageCheckBox1;
            this.guna2ImageCheckBox1.Size = new System.Drawing.Size(75, 23);
            this.guna2ImageCheckBox1.TabIndex = 33;
            this.guna2ImageCheckBox1.CheckedChanged += new System.EventHandler(this.guna2ImageCheckBox1_CheckedChanged);
            // 
            // guna2PictureBox7
            // 
            this.guna2PictureBox7.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox7.Image = global::SmartHome.Properties.Resources.woofer;
            this.guna2PictureBox7.Location = new System.Drawing.Point(7, 13);
            this.guna2PictureBox7.Name = "guna2PictureBox7";
            this.guna2PictureBox7.ShadowDecoration.Parent = this.guna2PictureBox7;
            this.guna2PictureBox7.Size = new System.Drawing.Size(65, 67);
            this.guna2PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox7.TabIndex = 0;
            this.guna2PictureBox7.TabStop = false;
            // 
            // guna2PictureBox6
            // 
            this.guna2PictureBox6.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox6.Image = global::SmartHome.Properties.Resources.window_blind;
            this.guna2PictureBox6.Location = new System.Drawing.Point(7, 3);
            this.guna2PictureBox6.Name = "guna2PictureBox6";
            this.guna2PictureBox6.ShadowDecoration.Parent = this.guna2PictureBox6;
            this.guna2PictureBox6.Size = new System.Drawing.Size(65, 67);
            this.guna2PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox6.TabIndex = 0;
            this.guna2PictureBox6.TabStop = false;
            // 
            // guna2PictureBox5
            // 
            this.guna2PictureBox5.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox5.Image = global::SmartHome.Properties.Resources.Robot_asp;
            this.guna2PictureBox5.Location = new System.Drawing.Point(7, 3);
            this.guna2PictureBox5.Name = "guna2PictureBox5";
            this.guna2PictureBox5.ShadowDecoration.Parent = this.guna2PictureBox5;
            this.guna2PictureBox5.Size = new System.Drawing.Size(65, 67);
            this.guna2PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox5.TabIndex = 0;
            this.guna2PictureBox5.TabStop = false;
            // 
            // lampe
            // 
            this.lampe.FillColor = System.Drawing.Color.Blue;
            this.lampe.Image = global::SmartHome.Properties.Resources.lampe;
            this.lampe.Location = new System.Drawing.Point(3, 3);
            this.lampe.Name = "lampe";
            this.lampe.ShadowDecoration.Parent = this.lampe;
            this.lampe.Size = new System.Drawing.Size(65, 67);
            this.lampe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lampe.TabIndex = 0;
            this.lampe.TabStop = false;
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox4.Image = global::SmartHome.Properties.Resources.door;
            this.guna2PictureBox4.Location = new System.Drawing.Point(7, 7);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.ShadowDecoration.Parent = this.guna2PictureBox4;
            this.guna2PictureBox4.Size = new System.Drawing.Size(65, 67);
            this.guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox4.TabIndex = 0;
            this.guna2PictureBox4.TabStop = false;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox1.Image = global::SmartHome.Properties.Resources.cam;
            this.guna2PictureBox1.Location = new System.Drawing.Point(12, 7);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(65, 67);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 0;
            this.guna2PictureBox1.TabStop = false;
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox2.Image = global::SmartHome.Properties.Resources.tv;
            this.guna2PictureBox2.Location = new System.Drawing.Point(12, 7);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.ShadowDecoration.Parent = this.guna2PictureBox2;
            this.guna2PictureBox2.Size = new System.Drawing.Size(65, 67);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox2.TabIndex = 0;
            this.guna2PictureBox2.TabStop = false;
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox3.Image = global::SmartHome.Properties.Resources.ac_off;
            this.guna2PictureBox3.Location = new System.Drawing.Point(14, -6);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(84, 83);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox3.TabIndex = 25;
            this.guna2PictureBox3.TabStop = false;
            this.guna2PictureBox3.UseTransparentBackground = true;
            // 
            // guna2ImageRadioButton5
            // 
            this.guna2ImageRadioButton5.CheckedState.Image = global::SmartHome.Properties.Resources.Auti_checked2;
            this.guna2ImageRadioButton5.CheckedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton5.CheckedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton5.CheckedState.Parent = this.guna2ImageRadioButton5;
            this.guna2ImageRadioButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2ImageRadioButton5.Enabled = false;
            this.guna2ImageRadioButton5.HoverState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton5.HoverState.Parent = this.guna2ImageRadioButton5;
            this.guna2ImageRadioButton5.Image = global::SmartHome.Properties.Resources.a_2_512;
            this.guna2ImageRadioButton5.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton5.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton5.Location = new System.Drawing.Point(137, 63);
            this.guna2ImageRadioButton5.Name = "guna2ImageRadioButton5";
            this.guna2ImageRadioButton5.PressedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton5.PressedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton5.PressedState.Parent = this.guna2ImageRadioButton5;
            this.guna2ImageRadioButton5.Size = new System.Drawing.Size(65, 84);
            this.guna2ImageRadioButton5.TabIndex = 16;
            this.guna2ImageRadioButton5.CheckedChanged += new System.EventHandler(this.guna2ImageRadioButton5_CheckedChanged_1);
            // 
            // guna2ImageRadioButton4
            // 
            this.guna2ImageRadioButton4.CheckedState.Image = global::SmartHome.Properties.Resources.sun_checked1;
            this.guna2ImageRadioButton4.CheckedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton4.CheckedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton4.CheckedState.Parent = this.guna2ImageRadioButton4;
            this.guna2ImageRadioButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2ImageRadioButton4.Enabled = false;
            this.guna2ImageRadioButton4.HoverState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton4.HoverState.Parent = this.guna2ImageRadioButton4;
            this.guna2ImageRadioButton4.Image = global::SmartHome.Properties.Resources.sun_37_512;
            this.guna2ImageRadioButton4.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton4.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton4.Location = new System.Drawing.Point(74, 63);
            this.guna2ImageRadioButton4.Name = "guna2ImageRadioButton4";
            this.guna2ImageRadioButton4.PressedState.Image = global::SmartHome.Properties.Resources.sun_37_512;
            this.guna2ImageRadioButton4.PressedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton4.PressedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton4.PressedState.Parent = this.guna2ImageRadioButton4;
            this.guna2ImageRadioButton4.Size = new System.Drawing.Size(65, 84);
            this.guna2ImageRadioButton4.TabIndex = 12;
            this.guna2ImageRadioButton4.CheckedChanged += new System.EventHandler(this.guna2ImageRadioButton4_CheckedChanged_1);
            // 
            // guna2ImageRadioButton1
            // 
            this.guna2ImageRadioButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ImageRadioButton1.CheckedState.Image = global::SmartHome.Properties.Resources.cold_checked;
            this.guna2ImageRadioButton1.CheckedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton1.CheckedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton1.CheckedState.Parent = this.guna2ImageRadioButton1;
            this.guna2ImageRadioButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2ImageRadioButton1.Enabled = false;
            this.guna2ImageRadioButton1.HoverState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton1.HoverState.Parent = this.guna2ImageRadioButton1;
            this.guna2ImageRadioButton1.Image = global::SmartHome.Properties.Resources.cold_5_512;
            this.guna2ImageRadioButton1.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton1.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton1.Location = new System.Drawing.Point(14, 63);
            this.guna2ImageRadioButton1.Name = "guna2ImageRadioButton1";
            this.guna2ImageRadioButton1.PressedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton1.PressedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton1.PressedState.Parent = this.guna2ImageRadioButton1;
            this.guna2ImageRadioButton1.Size = new System.Drawing.Size(65, 81);
            this.guna2ImageRadioButton1.TabIndex = 9;
            this.guna2ImageRadioButton1.UseTransparentBackground = true;
            this.guna2ImageRadioButton1.CheckedChanged += new System.EventHandler(this.guna2ImageRadioButton1_CheckedChanged_1);
            // 
            // guna2ImageCheckBox3
            // 
            this.guna2ImageCheckBox3.CheckedState.Image = global::SmartHome.Properties.Resources.lock_on;
            this.guna2ImageCheckBox3.CheckedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox3.CheckedState.Parent = this.guna2ImageCheckBox3;
            this.guna2ImageCheckBox3.HoverState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox3.HoverState.Parent = this.guna2ImageCheckBox3;
            this.guna2ImageCheckBox3.Image = global::SmartHome.Properties.Resources._lock;
            this.guna2ImageCheckBox3.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox3.Location = new System.Drawing.Point(149, 35);
            this.guna2ImageCheckBox3.Name = "guna2ImageCheckBox3";
            this.guna2ImageCheckBox3.PressedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox3.PressedState.Parent = this.guna2ImageCheckBox3;
            this.guna2ImageCheckBox3.Size = new System.Drawing.Size(47, 38);
            this.guna2ImageCheckBox3.TabIndex = 27;
            this.guna2ImageCheckBox3.CheckedChanged += new System.EventHandler(this.guna2ImageCheckBox3_CheckedChanged);
            // 
            // guna2ImageCheckBox2
            // 
            this.guna2ImageCheckBox2.CheckedState.Image = global::SmartHome.Properties.Resources.ice_on;
            this.guna2ImageCheckBox2.CheckedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox2.CheckedState.Parent = this.guna2ImageCheckBox2;
            this.guna2ImageCheckBox2.HoverState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox2.HoverState.Parent = this.guna2ImageCheckBox2;
            this.guna2ImageCheckBox2.Image = global::SmartHome.Properties.Resources.ice;
            this.guna2ImageCheckBox2.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox2.Location = new System.Drawing.Point(102, 35);
            this.guna2ImageCheckBox2.Name = "guna2ImageCheckBox2";
            this.guna2ImageCheckBox2.PressedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox2.PressedState.Parent = this.guna2ImageCheckBox2;
            this.guna2ImageCheckBox2.Size = new System.Drawing.Size(47, 38);
            this.guna2ImageCheckBox2.TabIndex = 26;
            this.guna2ImageCheckBox2.CheckedChanged += new System.EventHandler(this.guna2ImageCheckBox2_CheckedChanged);
            // 
            // guna2PictureBox9
            // 
            this.guna2PictureBox9.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox9.Image = global::SmartHome.Properties.Resources.frisge_on;
            this.guna2PictureBox9.Location = new System.Drawing.Point(14, 14);
            this.guna2PictureBox9.Name = "guna2PictureBox9";
            this.guna2PictureBox9.ShadowDecoration.Parent = this.guna2PictureBox9;
            this.guna2PictureBox9.Size = new System.Drawing.Size(84, 83);
            this.guna2PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox9.TabIndex = 25;
            this.guna2PictureBox9.TabStop = false;
            this.guna2PictureBox9.UseTransparentBackground = true;
            // 
            // guna2PictureBox10
            // 
            this.guna2PictureBox10.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox10.Image = global::SmartHome.Properties.Resources.cofee;
            this.guna2PictureBox10.Location = new System.Drawing.Point(7, 13);
            this.guna2PictureBox10.Name = "guna2PictureBox10";
            this.guna2PictureBox10.ShadowDecoration.Parent = this.guna2PictureBox10;
            this.guna2PictureBox10.Size = new System.Drawing.Size(65, 67);
            this.guna2PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox10.TabIndex = 0;
            this.guna2PictureBox10.TabStop = false;
            // 
            // Devices_list
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(503, 691);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.guna2ComboBox1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.guna2ControlBox2);
            this.Controls.Add(this.guna2ControlBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Devices_list";
            this.Text = "Devices_list";
            this.Load += new System.EventHandler(this.Devices_list_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.m3.ResumeLayout(false);
            this.m3.PerformLayout();
            this.m2.ResumeLayout(false);
            this.m2.PerformLayout();
            this.m1.ResumeLayout(false);
            this.m1.PerformLayout();
            this.m11.ResumeLayout(false);
            this.m11.PerformLayout();
            this.m4.ResumeLayout(false);
            this.m4.PerformLayout();
            this.m5.ResumeLayout(false);
            this.m5.PerformLayout();
            this.m6.ResumeLayout(false);
            this.m6.PerformLayout();
            this.m7.ResumeLayout(false);
            this.m7.PerformLayout();
            this.guna2CircleProgressBar1.ResumeLayout(false);
            this.guna2CircleProgressBar1.PerformLayout();
            this.m8.ResumeLayout(false);
            this.m8.PerformLayout();
            this.guna2CircleProgressBar2.ResumeLayout(false);
            this.guna2CircleProgressBar2.PerformLayout();
            this.m9.ResumeLayout(false);
            this.m9.PerformLayout();
            this.guna2CircleProgressBar4.ResumeLayout(false);
            this.guna2CircleProgressBar4.PerformLayout();
            this.m10.ResumeLayout(false);
            this.m10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lampe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox10)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox2;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Guna.UI2.WinForms.Guna2ShadowPanel m3;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch9;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox8;
        private Guna.UI2.WinForms.Guna2ShadowPanel m2;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar3;
        private Guna.UI2.WinForms.Guna2ImageCheckBox guna2ImageCheckBox1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton6;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton5;
        private Bunifu.Framework.UI.BunifuProgressBar bunifuProgressBar1;
        private System.Windows.Forms.Label label20;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch8;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox7;
        private Guna.UI2.WinForms.Guna2ShadowPanel m1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch7;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox6;
        private Guna.UI2.WinForms.Guna2ShadowPanel m11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label17;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox5;
        private Guna.UI2.WinForms.Guna2ShadowPanel m4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lampe_lab;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch5;
        private Guna.UI2.WinForms.Guna2PictureBox lampe;
        private Guna.UI2.WinForms.Guna2ShadowPanel m5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2ShadowPanel m6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2ShadowPanel m7;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2ShadowPanel m8;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton3;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton4;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar2;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton5;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton2;
        private System.Windows.Forms.Label label12;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton4;
        private System.Windows.Forms.Label label13;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton1;
        private Guna.UI2.WinForms.Guna2ShadowPanel m9;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox9;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton7;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton8;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar4;
        private System.Windows.Forms.Label label26;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton6;
        private System.Windows.Forms.Label label28;
        private Guna.UI2.WinForms.Guna2ImageCheckBox guna2ImageCheckBox2;
        private Guna.UI2.WinForms.Guna2ImageCheckBox guna2ImageCheckBox3;
        private Guna.UI2.WinForms.Guna2ShadowPanel m10;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch10;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox10;
        private System.Windows.Forms.Label label29;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
    }
}