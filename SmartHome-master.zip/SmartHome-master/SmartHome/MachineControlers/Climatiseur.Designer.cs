﻿namespace SmartHome.MachineControlers
{
    partial class Climatiseur
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m8 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.guna2ToggleSwitch3 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2GradientButton3 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton4 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2CircleProgressBar2 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label10 = new System.Windows.Forms.Label();
            this.guna2ImageRadioButton5 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.guna2ImageRadioButton2 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.guna2ImageRadioButton4 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.guna2ImageRadioButton1 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.m8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.guna2CircleProgressBar2.SuspendLayout();
            this.SuspendLayout();
            // 
            // m8
            // 
            this.m8.BackColor = System.Drawing.Color.Transparent;
            this.m8.Controls.Add(this.guna2ToggleSwitch3);
            this.m8.Controls.Add(this.guna2PictureBox3);
            this.m8.Controls.Add(this.guna2GradientButton3);
            this.m8.Controls.Add(this.guna2GradientButton4);
            this.m8.Controls.Add(this.label9);
            this.m8.Controls.Add(this.guna2CircleProgressBar2);
            this.m8.Controls.Add(this.guna2ImageRadioButton5);
            this.m8.Controls.Add(this.label11);
            this.m8.Controls.Add(this.guna2ImageRadioButton2);
            this.m8.Controls.Add(this.label12);
            this.m8.Controls.Add(this.guna2ImageRadioButton4);
            this.m8.Controls.Add(this.label13);
            this.m8.Controls.Add(this.guna2ImageRadioButton1);
            this.m8.FillColor = System.Drawing.Color.White;
            this.m8.Location = new System.Drawing.Point(3, 3);
            this.m8.Name = "m8";
            this.m8.Radius = 12;
            this.m8.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m8.ShadowDepth = 50;
            this.m8.ShadowShift = 6;
            this.m8.Size = new System.Drawing.Size(459, 144);
            this.m8.TabIndex = 39;
            this.m8.Paint += new System.Windows.Forms.PaintEventHandler(this.m8_Paint);
            this.m8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.m8_MouseDown);
            // 
            // guna2ToggleSwitch3
            // 
            this.guna2ToggleSwitch3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch3.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.CheckedState.Parent = this.guna2ToggleSwitch3;
            this.guna2ToggleSwitch3.Location = new System.Drawing.Point(97, 20);
            this.guna2ToggleSwitch3.Name = "guna2ToggleSwitch3";
            this.guna2ToggleSwitch3.ShadowDecoration.Parent = this.guna2ToggleSwitch3;
            this.guna2ToggleSwitch3.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch3.TabIndex = 25;
            this.guna2ToggleSwitch3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch3.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch3.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.UncheckedState.Parent = this.guna2ToggleSwitch3;
            this.guna2ToggleSwitch3.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch3_CheckedChanged);
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox3.Image = global::SmartHome.Properties.Resources.ac_off;
            this.guna2PictureBox3.Location = new System.Drawing.Point(14, -6);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(84, 83);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox3.TabIndex = 25;
            this.guna2PictureBox3.TabStop = false;
            this.guna2PictureBox3.UseTransparentBackground = true;
            // 
            // guna2GradientButton3
            // 
            this.guna2GradientButton3.BorderRadius = 6;
            this.guna2GradientButton3.CheckedState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton3.CustomImages.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Enabled = false;
            this.guna2GradientButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton3.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton3.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton3.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton3.HoverState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Location = new System.Drawing.Point(208, 71);
            this.guna2GradientButton3.Name = "guna2GradientButton3";
            this.guna2GradientButton3.ShadowDecoration.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Size = new System.Drawing.Size(45, 26);
            this.guna2GradientButton3.TabIndex = 22;
            this.guna2GradientButton3.Text = "-";
            this.guna2GradientButton3.Click += new System.EventHandler(this.guna2GradientButton3_Click);
            // 
            // guna2GradientButton4
            // 
            this.guna2GradientButton4.BorderRadius = 6;
            this.guna2GradientButton4.CheckedState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton4.CustomImages.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Enabled = false;
            this.guna2GradientButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton4.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton4.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton4.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton4.HoverState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Location = new System.Drawing.Point(388, 71);
            this.guna2GradientButton4.Name = "guna2GradientButton4";
            this.guna2GradientButton4.ShadowDecoration.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Size = new System.Drawing.Size(45, 26);
            this.guna2GradientButton4.TabIndex = 21;
            this.guna2GradientButton4.Text = "+";
            this.guna2GradientButton4.Click += new System.EventHandler(this.guna2GradientButton4_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label9.Location = new System.Drawing.Point(145, 114);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 21);
            this.label9.TabIndex = 20;
            this.label9.Text = "Auto";
            // 
            // guna2CircleProgressBar2
            // 
            this.guna2CircleProgressBar2.Animated = true;
            this.guna2CircleProgressBar2.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleProgressBar2.Controls.Add(this.label10);
            this.guna2CircleProgressBar2.FillThickness = 15;
            this.guna2CircleProgressBar2.Location = new System.Drawing.Point(272, 28);
            this.guna2CircleProgressBar2.Maximum = 31;
            this.guna2CircleProgressBar2.Name = "guna2CircleProgressBar2";
            this.guna2CircleProgressBar2.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2CircleProgressBar2.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2CircleProgressBar2.ProgressEndCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar2.ProgressStartCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar2.ProgressThickness = 15;
            this.guna2CircleProgressBar2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar2.ShadowDecoration.Parent = this.guna2CircleProgressBar2;
            this.guna2CircleProgressBar2.Size = new System.Drawing.Size(100, 100);
            this.guna2CircleProgressBar2.TabIndex = 19;
            this.guna2CircleProgressBar2.UseTransparentBackground = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label10.Location = new System.Drawing.Point(26, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 21);
            this.label10.TabIndex = 21;
            this.label10.Text = "+0 C";
            // 
            // guna2ImageRadioButton5
            // 
            this.guna2ImageRadioButton5.CheckedState.Image = global::SmartHome.Properties.Resources.Auti_checked2;
            this.guna2ImageRadioButton5.CheckedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton5.CheckedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton5.CheckedState.Parent = this.guna2ImageRadioButton5;
            this.guna2ImageRadioButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2ImageRadioButton5.Enabled = false;
            this.guna2ImageRadioButton5.HoverState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton5.HoverState.Parent = this.guna2ImageRadioButton5;
            this.guna2ImageRadioButton5.Image = global::SmartHome.Properties.Resources.a_2_512;
            this.guna2ImageRadioButton5.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton5.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton5.Location = new System.Drawing.Point(137, 63);
            this.guna2ImageRadioButton5.Name = "guna2ImageRadioButton5";
            this.guna2ImageRadioButton5.PressedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton5.PressedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton5.PressedState.Parent = this.guna2ImageRadioButton5;
            this.guna2ImageRadioButton5.Size = new System.Drawing.Size(65, 84);
            this.guna2ImageRadioButton5.TabIndex = 16;
            this.guna2ImageRadioButton5.CheckedChanged += new System.EventHandler(this.guna2ImageRadioButton5_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label11.Location = new System.Drawing.Point(85, 114);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 21);
            this.label11.TabIndex = 19;
            this.label11.Text = "Heat";
            // 
            // guna2ImageRadioButton2
            // 
            this.guna2ImageRadioButton2.CheckedState.Parent = this.guna2ImageRadioButton2;
            this.guna2ImageRadioButton2.HoverState.Parent = this.guna2ImageRadioButton2;
            this.guna2ImageRadioButton2.Location = new System.Drawing.Point(72, 342);
            this.guna2ImageRadioButton2.Name = "guna2ImageRadioButton2";
            this.guna2ImageRadioButton2.PressedState.Parent = this.guna2ImageRadioButton2;
            this.guna2ImageRadioButton2.Size = new System.Drawing.Size(75, 23);
            this.guna2ImageRadioButton2.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label12.Location = new System.Drawing.Point(141, 4);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(155, 21);
            this.label12.TabIndex = 2;
            this.label12.Text = "Room temperature";
            // 
            // guna2ImageRadioButton4
            // 
            this.guna2ImageRadioButton4.CheckedState.Image = global::SmartHome.Properties.Resources.sun_checked1;
            this.guna2ImageRadioButton4.CheckedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton4.CheckedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton4.CheckedState.Parent = this.guna2ImageRadioButton4;
            this.guna2ImageRadioButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2ImageRadioButton4.Enabled = false;
            this.guna2ImageRadioButton4.HoverState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton4.HoverState.Parent = this.guna2ImageRadioButton4;
            this.guna2ImageRadioButton4.Image = global::SmartHome.Properties.Resources.sun_37_512;
            this.guna2ImageRadioButton4.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton4.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton4.Location = new System.Drawing.Point(74, 63);
            this.guna2ImageRadioButton4.Name = "guna2ImageRadioButton4";
            this.guna2ImageRadioButton4.PressedState.Image = global::SmartHome.Properties.Resources.sun_37_512;
            this.guna2ImageRadioButton4.PressedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton4.PressedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton4.PressedState.Parent = this.guna2ImageRadioButton4;
            this.guna2ImageRadioButton4.Size = new System.Drawing.Size(65, 84);
            this.guna2ImageRadioButton4.TabIndex = 12;
            this.guna2ImageRadioButton4.CheckedChanged += new System.EventHandler(this.guna2ImageRadioButton4_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label13.Location = new System.Drawing.Point(24, 114);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 21);
            this.label13.TabIndex = 18;
            this.label13.Text = "Cool";
            // 
            // guna2ImageRadioButton1
            // 
            this.guna2ImageRadioButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ImageRadioButton1.CheckedState.Image = global::SmartHome.Properties.Resources.cold_checked;
            this.guna2ImageRadioButton1.CheckedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton1.CheckedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton1.CheckedState.Parent = this.guna2ImageRadioButton1;
            this.guna2ImageRadioButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2ImageRadioButton1.Enabled = false;
            this.guna2ImageRadioButton1.HoverState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton1.HoverState.Parent = this.guna2ImageRadioButton1;
            this.guna2ImageRadioButton1.Image = global::SmartHome.Properties.Resources.cold_5_512;
            this.guna2ImageRadioButton1.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton1.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton1.Location = new System.Drawing.Point(14, 63);
            this.guna2ImageRadioButton1.Name = "guna2ImageRadioButton1";
            this.guna2ImageRadioButton1.PressedState.ImageOffset = new System.Drawing.Point(0, -10);
            this.guna2ImageRadioButton1.PressedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageRadioButton1.PressedState.Parent = this.guna2ImageRadioButton1;
            this.guna2ImageRadioButton1.Size = new System.Drawing.Size(65, 81);
            this.guna2ImageRadioButton1.TabIndex = 9;
            this.guna2ImageRadioButton1.UseTransparentBackground = true;
            this.guna2ImageRadioButton1.CheckedChanged += new System.EventHandler(this.guna2ImageRadioButton1_CheckedChanged);
            // 
            // Climatiseur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.m8);
            this.Name = "Climatiseur";
            this.Size = new System.Drawing.Size(467, 154);
            this.Load += new System.EventHandler(this.Climatiseur_Load);
            this.m8.ResumeLayout(false);
            this.m8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.guna2CircleProgressBar2.ResumeLayout(false);
            this.guna2CircleProgressBar2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ShadowPanel m8;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton3;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton4;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar2;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton5;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton2;
        private System.Windows.Forms.Label label12;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton4;
        private System.Windows.Forms.Label label13;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton1;
    }
}
