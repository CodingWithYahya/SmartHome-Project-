﻿namespace SmartHome.MachineControlers
{
    partial class Tlaja
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m9 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.guna2GradientButton7 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton8 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2CircleProgressBar4 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label26 = new System.Windows.Forms.Label();
            this.guna2ImageRadioButton6 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.label28 = new System.Windows.Forms.Label();
            this.guna2ImageCheckBox3 = new Guna.UI2.WinForms.Guna2ImageCheckBox();
            this.guna2ImageCheckBox2 = new Guna.UI2.WinForms.Guna2ImageCheckBox();
            this.guna2PictureBox9 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.m9.SuspendLayout();
            this.guna2CircleProgressBar4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // m9
            // 
            this.m9.BackColor = System.Drawing.Color.Transparent;
            this.m9.Controls.Add(this.guna2ImageCheckBox3);
            this.m9.Controls.Add(this.guna2ImageCheckBox2);
            this.m9.Controls.Add(this.guna2PictureBox9);
            this.m9.Controls.Add(this.guna2GradientButton7);
            this.m9.Controls.Add(this.guna2GradientButton8);
            this.m9.Controls.Add(this.guna2CircleProgressBar4);
            this.m9.Controls.Add(this.guna2ImageRadioButton6);
            this.m9.Controls.Add(this.label28);
            this.m9.FillColor = System.Drawing.Color.White;
            this.m9.Location = new System.Drawing.Point(0, 0);
            this.m9.Name = "m9";
            this.m9.Radius = 12;
            this.m9.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m9.ShadowDepth = 50;
            this.m9.ShadowShift = 6;
            this.m9.Size = new System.Drawing.Size(459, 144);
            this.m9.TabIndex = 40;
            this.m9.Paint += new System.Windows.Forms.PaintEventHandler(this.m9_Paint);
            this.m9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.m9_MouseDown);
            // 
            // guna2GradientButton7
            // 
            this.guna2GradientButton7.BorderRadius = 6;
            this.guna2GradientButton7.CheckedState.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton7.CustomImages.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton7.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton7.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton7.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton7.HoverState.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Location = new System.Drawing.Point(208, 71);
            this.guna2GradientButton7.Name = "guna2GradientButton7";
            this.guna2GradientButton7.ShadowDecoration.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Size = new System.Drawing.Size(45, 26);
            this.guna2GradientButton7.TabIndex = 22;
            this.guna2GradientButton7.Text = "-";
            this.guna2GradientButton7.Click += new System.EventHandler(this.guna2GradientButton7_Click);
            // 
            // guna2GradientButton8
            // 
            this.guna2GradientButton8.BorderRadius = 6;
            this.guna2GradientButton8.CheckedState.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2GradientButton8.CustomImages.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2GradientButton8.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2GradientButton8.Font = new System.Drawing.Font("Montserrat SemiBold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton8.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton8.HoverState.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Location = new System.Drawing.Point(388, 71);
            this.guna2GradientButton8.Name = "guna2GradientButton8";
            this.guna2GradientButton8.ShadowDecoration.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Size = new System.Drawing.Size(45, 26);
            this.guna2GradientButton8.TabIndex = 21;
            this.guna2GradientButton8.Text = "+";
            this.guna2GradientButton8.Click += new System.EventHandler(this.guna2GradientButton8_Click);
            // 
            // guna2CircleProgressBar4
            // 
            this.guna2CircleProgressBar4.Animated = true;
            this.guna2CircleProgressBar4.AnimationSpeed = 0.3F;
            this.guna2CircleProgressBar4.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleProgressBar4.Controls.Add(this.label26);
            this.guna2CircleProgressBar4.FillThickness = 15;
            this.guna2CircleProgressBar4.Location = new System.Drawing.Point(272, 28);
            this.guna2CircleProgressBar4.Maximum = 31;
            this.guna2CircleProgressBar4.Name = "guna2CircleProgressBar4";
            this.guna2CircleProgressBar4.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2CircleProgressBar4.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2CircleProgressBar4.ProgressEndCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar4.ProgressStartCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar4.ProgressThickness = 15;
            this.guna2CircleProgressBar4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar4.ShadowDecoration.Parent = this.guna2CircleProgressBar4;
            this.guna2CircleProgressBar4.Size = new System.Drawing.Size(100, 100);
            this.guna2CircleProgressBar4.TabIndex = 19;
            this.guna2CircleProgressBar4.UseTransparentBackground = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label26.Location = new System.Drawing.Point(27, 40);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(44, 21);
            this.label26.TabIndex = 21;
            this.label26.Text = "+0 C";
            // 
            // guna2ImageRadioButton6
            // 
            this.guna2ImageRadioButton6.CheckedState.Parent = this.guna2ImageRadioButton6;
            this.guna2ImageRadioButton6.HoverState.Parent = this.guna2ImageRadioButton6;
            this.guna2ImageRadioButton6.Location = new System.Drawing.Point(72, 342);
            this.guna2ImageRadioButton6.Name = "guna2ImageRadioButton6";
            this.guna2ImageRadioButton6.PressedState.Parent = this.guna2ImageRadioButton6;
            this.guna2ImageRadioButton6.Size = new System.Drawing.Size(75, 23);
            this.guna2ImageRadioButton6.TabIndex = 17;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label28.Location = new System.Drawing.Point(27, 99);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 21);
            this.label28.TabIndex = 2;
            this.label28.Text = "Fridge";
            // 
            // guna2ImageCheckBox3
            // 
            this.guna2ImageCheckBox3.CheckedState.Image = global::SmartHome.Properties.Resources.lock_on;
            this.guna2ImageCheckBox3.CheckedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox3.CheckedState.Parent = this.guna2ImageCheckBox3;
            this.guna2ImageCheckBox3.HoverState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox3.HoverState.Parent = this.guna2ImageCheckBox3;
            this.guna2ImageCheckBox3.Image = global::SmartHome.Properties.Resources._lock;
            this.guna2ImageCheckBox3.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox3.Location = new System.Drawing.Point(149, 35);
            this.guna2ImageCheckBox3.Name = "guna2ImageCheckBox3";
            this.guna2ImageCheckBox3.PressedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox3.PressedState.Parent = this.guna2ImageCheckBox3;
            this.guna2ImageCheckBox3.Size = new System.Drawing.Size(47, 38);
            this.guna2ImageCheckBox3.TabIndex = 27;
            this.guna2ImageCheckBox3.CheckedChanged += new System.EventHandler(this.guna2ImageCheckBox3_CheckedChanged);
            // 
            // guna2ImageCheckBox2
            // 
            this.guna2ImageCheckBox2.CheckedState.Image = global::SmartHome.Properties.Resources.ice_on;
            this.guna2ImageCheckBox2.CheckedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox2.CheckedState.Parent = this.guna2ImageCheckBox2;
            this.guna2ImageCheckBox2.HoverState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox2.HoverState.Parent = this.guna2ImageCheckBox2;
            this.guna2ImageCheckBox2.Image = global::SmartHome.Properties.Resources.ice;
            this.guna2ImageCheckBox2.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox2.Location = new System.Drawing.Point(102, 35);
            this.guna2ImageCheckBox2.Name = "guna2ImageCheckBox2";
            this.guna2ImageCheckBox2.PressedState.ImageSize = new System.Drawing.Size(35, 35);
            this.guna2ImageCheckBox2.PressedState.Parent = this.guna2ImageCheckBox2;
            this.guna2ImageCheckBox2.Size = new System.Drawing.Size(47, 38);
            this.guna2ImageCheckBox2.TabIndex = 26;
            this.guna2ImageCheckBox2.CheckedChanged += new System.EventHandler(this.guna2ImageCheckBox2_CheckedChanged);
            // 
            // guna2PictureBox9
            // 
            this.guna2PictureBox9.FillColor = System.Drawing.Color.Blue;
            this.guna2PictureBox9.Image = global::SmartHome.Properties.Resources.frisge_on;
            this.guna2PictureBox9.Location = new System.Drawing.Point(14, 14);
            this.guna2PictureBox9.Name = "guna2PictureBox9";
            this.guna2PictureBox9.ShadowDecoration.Parent = this.guna2PictureBox9;
            this.guna2PictureBox9.Size = new System.Drawing.Size(84, 83);
            this.guna2PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox9.TabIndex = 25;
            this.guna2PictureBox9.TabStop = false;
            this.guna2PictureBox9.UseTransparentBackground = true;
            // 
            // Tlaja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.m9);
            this.Name = "Tlaja";
            this.Size = new System.Drawing.Size(462, 147);
            this.m9.ResumeLayout(false);
            this.m9.PerformLayout();
            this.guna2CircleProgressBar4.ResumeLayout(false);
            this.guna2CircleProgressBar4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ShadowPanel m9;
        private Guna.UI2.WinForms.Guna2ImageCheckBox guna2ImageCheckBox3;
        private Guna.UI2.WinForms.Guna2ImageCheckBox guna2ImageCheckBox2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox9;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton7;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton8;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar4;
        private System.Windows.Forms.Label label26;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton6;
        private System.Windows.Forms.Label label28;
    }
}
