﻿namespace SmartHome
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2ShadowPanel2 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2VProgressBar1 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.guna2CircleProgressBar2 = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.guna2ImageRadioButton6 = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.guna2ToggleSwitch5 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.cam_lab = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.m4 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.m3 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.guna2ToggleSwitch1 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.guna2ToggleSwitch2 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.guna2ShadowPanel3 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.guna2ToggleSwitch3 = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.guna2PictureBox12 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox11 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox10 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox9 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox8 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox7 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox6 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.cam = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.garage1 = new SmartHome.MachineControlers.Garage();
            this.wifi1 = new SmartHome.MachineControlers.Wifi();
            this.guna2ShadowPanel2.SuspendLayout();
            this.m4.SuspendLayout();
            this.m3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.guna2ShadowPanel1.SuspendLayout();
            this.guna2ShadowPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2ShadowPanel2
            // 
            this.guna2ShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel2.Controls.Add(this.label3);
            this.guna2ShadowPanel2.Controls.Add(this.guna2VProgressBar1);
            this.guna2ShadowPanel2.Controls.Add(this.guna2CircleProgressBar2);
            this.guna2ShadowPanel2.Controls.Add(this.label11);
            this.guna2ShadowPanel2.Controls.Add(this.label9);
            this.guna2ShadowPanel2.Controls.Add(this.label10);
            this.guna2ShadowPanel2.Controls.Add(this.guna2PictureBox2);
            this.guna2ShadowPanel2.Controls.Add(this.label8);
            this.guna2ShadowPanel2.Controls.Add(this.guna2ImageRadioButton6);
            this.guna2ShadowPanel2.Controls.Add(this.label1);
            this.guna2ShadowPanel2.Controls.Add(this.label2);
            this.guna2ShadowPanel2.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel2.Location = new System.Drawing.Point(12, 17);
            this.guna2ShadowPanel2.Name = "guna2ShadowPanel2";
            this.guna2ShadowPanel2.Radius = 12;
            this.guna2ShadowPanel2.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2ShadowPanel2.ShadowDepth = 50;
            this.guna2ShadowPanel2.ShadowShift = 6;
            this.guna2ShadowPanel2.Size = new System.Drawing.Size(536, 167);
            this.guna2ShadowPanel2.TabIndex = 33;
            this.guna2ShadowPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2ShadowPanel2_Paint);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label3.Location = new System.Drawing.Point(143, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 21);
            this.label3.TabIndex = 27;
            this.label3.Text = "label3";
            // 
            // guna2VProgressBar1
            // 
            this.guna2VProgressBar1.AutoRoundedCorners = true;
            this.guna2VProgressBar1.BorderRadius = 14;
            this.guna2VProgressBar1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.guna2VProgressBar1.Location = new System.Drawing.Point(454, 19);
            this.guna2VProgressBar1.Maximum = 50;
            this.guna2VProgressBar1.Name = "guna2VProgressBar1";
            this.guna2VProgressBar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2VProgressBar1.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2VProgressBar1.ShadowDecoration.Parent = this.guna2VProgressBar1;
            this.guna2VProgressBar1.Size = new System.Drawing.Size(30, 133);
            this.guna2VProgressBar1.TabIndex = 24;
            this.guna2VProgressBar1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.guna2VProgressBar1.Value = 13;
            // 
            // guna2CircleProgressBar2
            // 
            this.guna2CircleProgressBar2.Animated = true;
            this.guna2CircleProgressBar2.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleProgressBar2.Location = new System.Drawing.Point(308, 24);
            this.guna2CircleProgressBar2.Name = "guna2CircleProgressBar2";
            this.guna2CircleProgressBar2.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2CircleProgressBar2.ProgressColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(11)))), ((int)(((byte)(255)))));
            this.guna2CircleProgressBar2.ProgressEndCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar2.ProgressStartCap = System.Drawing.Drawing2D.LineCap.Round;
            this.guna2CircleProgressBar2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleProgressBar2.ShadowDecoration.Parent = this.guna2CircleProgressBar2;
            this.guna2CircleProgressBar2.Size = new System.Drawing.Size(130, 130);
            this.guna2CircleProgressBar2.TabIndex = 22;
            this.guna2CircleProgressBar2.UseTransparentBackground = true;
            this.guna2CircleProgressBar2.Value = 24;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Montserrat", 9F);
            this.label11.Location = new System.Drawing.Point(26, 142);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 16);
            this.label11.TabIndex = 26;
            this.label11.Text = "Marrakech";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label9.Location = new System.Drawing.Point(24, 121);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 21);
            this.label9.TabIndex = 25;
            this.label9.Text = "Outdoor Temp";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label10.Location = new System.Drawing.Point(24, 93);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 21);
            this.label10.TabIndex = 23;
            this.label10.Text = "+24 C";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Montserrat", 10.75F);
            this.label8.Location = new System.Drawing.Point(24, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(135, 21);
            this.label8.TabIndex = 23;
            this.label8.Text = "Welcome Home!";
            // 
            // guna2ImageRadioButton6
            // 
            this.guna2ImageRadioButton6.CheckedState.Parent = this.guna2ImageRadioButton6;
            this.guna2ImageRadioButton6.HoverState.Parent = this.guna2ImageRadioButton6;
            this.guna2ImageRadioButton6.Location = new System.Drawing.Point(72, 342);
            this.guna2ImageRadioButton6.Name = "guna2ImageRadioButton6";
            this.guna2ImageRadioButton6.PressedState.Parent = this.guna2ImageRadioButton6;
            this.guna2ImageRadioButton6.Size = new System.Drawing.Size(75, 23);
            this.guna2ImageRadioButton6.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Montserrat", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hello,";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Montserrat Medium", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(119, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "Admin !!!!!!";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Montserrat", 15F);
            this.label4.Location = new System.Drawing.Point(602, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 27);
            this.label4.TabIndex = 42;
            this.label4.Text = "Shortcuts";
            // 
            // guna2ToggleSwitch5
            // 
            this.guna2ToggleSwitch5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch5.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch5.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch5.CheckedState.Parent = this.guna2ToggleSwitch5;
            this.guna2ToggleSwitch5.Location = new System.Drawing.Point(90, 22);
            this.guna2ToggleSwitch5.Name = "guna2ToggleSwitch5";
            this.guna2ToggleSwitch5.ShadowDecoration.Parent = this.guna2ToggleSwitch5;
            this.guna2ToggleSwitch5.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch5.TabIndex = 15;
            this.guna2ToggleSwitch5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch5.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch5.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch5.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch5.UncheckedState.Parent = this.guna2ToggleSwitch5;
            this.guna2ToggleSwitch5.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch5_CheckedChanged);
            // 
            // cam_lab
            // 
            this.cam_lab.AutoSize = true;
            this.cam_lab.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cam_lab.Location = new System.Drawing.Point(97, 54);
            this.cam_lab.Name = "cam_lab";
            this.cam_lab.Size = new System.Drawing.Size(27, 14);
            this.cam_lab.TabIndex = 2;
            this.cam_lab.Text = "OFF";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Montserrat SemiBold", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(56, 111);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 14);
            this.label16.TabIndex = 16;
            this.label16.Text = "Camera";
            // 
            // m4
            // 
            this.m4.BackColor = System.Drawing.Color.Transparent;
            this.m4.Controls.Add(this.label16);
            this.m4.Controls.Add(this.cam_lab);
            this.m4.Controls.Add(this.guna2ToggleSwitch5);
            this.m4.Controls.Add(this.cam);
            this.m4.FillColor = System.Drawing.Color.White;
            this.m4.Location = new System.Drawing.Point(724, 41);
            this.m4.Name = "m4";
            this.m4.Radius = 12;
            this.m4.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m4.ShadowDepth = 70;
            this.m4.Size = new System.Drawing.Size(147, 144);
            this.m4.TabIndex = 43;
            this.m4.Paint += new System.Windows.Forms.PaintEventHandler(this.m4_Paint);
            // 
            // m3
            // 
            this.m3.BackColor = System.Drawing.Color.Transparent;
            this.m3.Controls.Add(this.guna2ToggleSwitch1);
            this.m3.Controls.Add(this.guna2PictureBox1);
            this.m3.FillColor = System.Drawing.Color.White;
            this.m3.Location = new System.Drawing.Point(12, 270);
            this.m3.Name = "m3";
            this.m3.Radius = 12;
            this.m3.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.m3.ShadowDepth = 30;
            this.m3.Size = new System.Drawing.Size(136, 65);
            this.m3.TabIndex = 47;
            // 
            // guna2ToggleSwitch1
            // 
            this.guna2ToggleSwitch1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch1.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch1.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch1.CheckedState.Parent = this.guna2ToggleSwitch1;
            this.guna2ToggleSwitch1.Location = new System.Drawing.Point(72, 21);
            this.guna2ToggleSwitch1.Name = "guna2ToggleSwitch1";
            this.guna2ToggleSwitch1.ShadowDecoration.Parent = this.guna2ToggleSwitch1;
            this.guna2ToggleSwitch1.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch1.TabIndex = 49;
            this.guna2ToggleSwitch1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch1.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch1.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch1.UncheckedState.Parent = this.guna2ToggleSwitch1;
            this.guna2ToggleSwitch1.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch1_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Montserrat", 15F);
            this.label5.Location = new System.Drawing.Point(40, 236);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 27);
            this.label5.TabIndex = 48;
            this.label5.Text = "Night mode";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Montserrat", 15F);
            this.label6.Location = new System.Drawing.Point(594, 204);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(176, 27);
            this.label6.TabIndex = 49;
            this.label6.Text = "Camera Preview";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.guna2PictureBox6, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.guna2PictureBox5, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.guna2PictureBox4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.guna2PictureBox3, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(562, 233);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(461, 322);
            this.tableLayoutPanel1.TabIndex = 50;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Montserrat", 15F);
            this.label7.Location = new System.Drawing.Point(42, 364);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 27);
            this.label7.TabIndex = 51;
            this.label7.Text = "Security";
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.Controls.Add(this.guna2ToggleSwitch2);
            this.guna2ShadowPanel1.Controls.Add(this.guna2PictureBox7);
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(12, 399);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.Radius = 12;
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2ShadowPanel1.ShadowDepth = 30;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(58, 136);
            this.guna2ShadowPanel1.TabIndex = 50;
            // 
            // guna2ToggleSwitch2
            // 
            this.guna2ToggleSwitch2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch2.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch2.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch2.CheckedState.Parent = this.guna2ToggleSwitch2;
            this.guna2ToggleSwitch2.Location = new System.Drawing.Point(8, 90);
            this.guna2ToggleSwitch2.Name = "guna2ToggleSwitch2";
            this.guna2ToggleSwitch2.ShadowDecoration.Parent = this.guna2ToggleSwitch2;
            this.guna2ToggleSwitch2.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch2.TabIndex = 49;
            this.guna2ToggleSwitch2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch2.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch2.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch2.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch2.UncheckedState.Parent = this.guna2ToggleSwitch2;
            this.guna2ToggleSwitch2.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch2_CheckedChanged);
            // 
            // guna2ShadowPanel3
            // 
            this.guna2ShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel3.Controls.Add(this.guna2ToggleSwitch3);
            this.guna2ShadowPanel3.Controls.Add(this.guna2PictureBox8);
            this.guna2ShadowPanel3.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel3.Location = new System.Drawing.Point(76, 399);
            this.guna2ShadowPanel3.Name = "guna2ShadowPanel3";
            this.guna2ShadowPanel3.Radius = 12;
            this.guna2ShadowPanel3.ShadowColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(4)))), ((int)(((byte)(83)))));
            this.guna2ShadowPanel3.ShadowDepth = 30;
            this.guna2ShadowPanel3.Size = new System.Drawing.Size(58, 136);
            this.guna2ShadowPanel3.TabIndex = 51;
            // 
            // guna2ToggleSwitch3
            // 
            this.guna2ToggleSwitch3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(6)))), ((int)(((byte)(123)))));
            this.guna2ToggleSwitch3.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.CheckedState.Parent = this.guna2ToggleSwitch3;
            this.guna2ToggleSwitch3.Location = new System.Drawing.Point(8, 90);
            this.guna2ToggleSwitch3.Name = "guna2ToggleSwitch3";
            this.guna2ToggleSwitch3.ShadowDecoration.Parent = this.guna2ToggleSwitch3;
            this.guna2ToggleSwitch3.Size = new System.Drawing.Size(42, 23);
            this.guna2ToggleSwitch3.TabIndex = 49;
            this.guna2ToggleSwitch3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch3.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2ToggleSwitch3.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2ToggleSwitch3.UncheckedState.Parent = this.guna2ToggleSwitch3;
            this.guna2ToggleSwitch3.CheckedChanged += new System.EventHandler(this.guna2ToggleSwitch3_CheckedChanged);
            // 
            // guna2PictureBox12
            // 
            this.guna2PictureBox12.Image = global::SmartHome.Properties.Resources.shortcut_script_app;
            this.guna2PictureBox12.Location = new System.Drawing.Point(571, 7);
            this.guna2PictureBox12.Name = "guna2PictureBox12";
            this.guna2PictureBox12.ShadowDecoration.Parent = this.guna2PictureBox12;
            this.guna2PictureBox12.Size = new System.Drawing.Size(31, 33);
            this.guna2PictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox12.TabIndex = 54;
            this.guna2PictureBox12.TabStop = false;
            // 
            // guna2PictureBox11
            // 
            this.guna2PictureBox11.Image = global::SmartHome.Properties.Resources.cctv_camera;
            this.guna2PictureBox11.Location = new System.Drawing.Point(565, 200);
            this.guna2PictureBox11.Name = "guna2PictureBox11";
            this.guna2PictureBox11.ShadowDecoration.Parent = this.guna2PictureBox11;
            this.guna2PictureBox11.Size = new System.Drawing.Size(31, 33);
            this.guna2PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox11.TabIndex = 53;
            this.guna2PictureBox11.TabStop = false;
            // 
            // guna2PictureBox10
            // 
            this.guna2PictureBox10.Image = global::SmartHome.Properties.Resources.night_mode;
            this.guna2PictureBox10.Location = new System.Drawing.Point(12, 235);
            this.guna2PictureBox10.Name = "guna2PictureBox10";
            this.guna2PictureBox10.ShadowDecoration.Parent = this.guna2PictureBox10;
            this.guna2PictureBox10.Size = new System.Drawing.Size(31, 28);
            this.guna2PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox10.TabIndex = 52;
            this.guna2PictureBox10.TabStop = false;
            // 
            // guna2PictureBox9
            // 
            this.guna2PictureBox9.Image = global::SmartHome.Properties.Resources.alarme;
            this.guna2PictureBox9.Location = new System.Drawing.Point(12, 358);
            this.guna2PictureBox9.Name = "guna2PictureBox9";
            this.guna2PictureBox9.ShadowDecoration.Parent = this.guna2PictureBox9;
            this.guna2PictureBox9.Size = new System.Drawing.Size(31, 33);
            this.guna2PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox9.TabIndex = 50;
            this.guna2PictureBox9.TabStop = false;
            // 
            // guna2PictureBox8
            // 
            this.guna2PictureBox8.Image = global::SmartHome.Properties.Resources.fire_detector;
            this.guna2PictureBox8.Location = new System.Drawing.Point(8, 19);
            this.guna2PictureBox8.Name = "guna2PictureBox8";
            this.guna2PictureBox8.ShadowDecoration.Parent = this.guna2PictureBox8;
            this.guna2PictureBox8.Size = new System.Drawing.Size(40, 48);
            this.guna2PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox8.TabIndex = 48;
            this.guna2PictureBox8.TabStop = false;
            // 
            // guna2PictureBox7
            // 
            this.guna2PictureBox7.Image = global::SmartHome.Properties.Resources.smoke_detector;
            this.guna2PictureBox7.Location = new System.Drawing.Point(8, 19);
            this.guna2PictureBox7.Name = "guna2PictureBox7";
            this.guna2PictureBox7.ShadowDecoration.Parent = this.guna2PictureBox7;
            this.guna2PictureBox7.Size = new System.Drawing.Size(40, 48);
            this.guna2PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox7.TabIndex = 48;
            this.guna2PictureBox7.TabStop = false;
            // 
            // guna2PictureBox6
            // 
            this.guna2PictureBox6.Image = global::SmartHome.Properties.Resources.no_signal_cctv_1024x5761;
            this.guna2PictureBox6.Location = new System.Drawing.Point(233, 164);
            this.guna2PictureBox6.Name = "guna2PictureBox6";
            this.guna2PictureBox6.ShadowDecoration.Parent = this.guna2PictureBox6;
            this.guna2PictureBox6.Size = new System.Drawing.Size(225, 155);
            this.guna2PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox6.TabIndex = 3;
            this.guna2PictureBox6.TabStop = false;
            // 
            // guna2PictureBox5
            // 
            this.guna2PictureBox5.Image = global::SmartHome.Properties.Resources.no_signal_cctv_1024x5761;
            this.guna2PictureBox5.Location = new System.Drawing.Point(3, 164);
            this.guna2PictureBox5.Name = "guna2PictureBox5";
            this.guna2PictureBox5.ShadowDecoration.Parent = this.guna2PictureBox5;
            this.guna2PictureBox5.Size = new System.Drawing.Size(224, 155);
            this.guna2PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox5.TabIndex = 2;
            this.guna2PictureBox5.TabStop = false;
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.Image = global::SmartHome.Properties.Resources.no_signal_cctv_1024x5761;
            this.guna2PictureBox4.Location = new System.Drawing.Point(3, 3);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.ShadowDecoration.Parent = this.guna2PictureBox4;
            this.guna2PictureBox4.Size = new System.Drawing.Size(224, 155);
            this.guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox4.TabIndex = 1;
            this.guna2PictureBox4.TabStop = false;
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.Image = global::SmartHome.Properties.Resources.no_signal_cctv_1024x5761;
            this.guna2PictureBox3.Location = new System.Drawing.Point(233, 3);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(225, 155);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox3.TabIndex = 0;
            this.guna2PictureBox3.TabStop = false;
            this.guna2PictureBox3.Click += new System.EventHandler(this.guna2PictureBox3_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = global::SmartHome.Properties.Resources.night;
            this.guna2PictureBox1.Location = new System.Drawing.Point(18, 8);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(40, 48);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 48;
            this.guna2PictureBox1.TabStop = false;
            // 
            // cam
            // 
            this.cam.FillColor = System.Drawing.Color.Blue;
            this.cam.Image = global::SmartHome.Properties.Resources.cam;
            this.cam.Location = new System.Drawing.Point(3, 3);
            this.cam.Name = "cam";
            this.cam.ShadowDecoration.Parent = this.cam;
            this.cam.Size = new System.Drawing.Size(65, 67);
            this.cam.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.cam.TabIndex = 0;
            this.cam.TabStop = false;
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.Image = global::SmartHome.Properties.Resources.weather_43_512;
            this.guna2PictureBox2.Location = new System.Drawing.Point(60, 84);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.ShadowDecoration.Parent = this.guna2PictureBox2;
            this.guna2PictureBox2.Size = new System.Drawing.Size(76, 33);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox2.TabIndex = 24;
            this.guna2PictureBox2.TabStop = false;
            // 
            // garage1
            // 
            this.garage1.Location = new System.Drawing.Point(877, 37);
            this.garage1.Name = "garage1";
            this.garage1.Size = new System.Drawing.Size(150, 150);
            this.garage1.TabIndex = 46;
            // 
            // wifi1
            // 
            this.wifi1.Location = new System.Drawing.Point(571, 37);
            this.wifi1.Name = "wifi1";
            this.wifi1.Size = new System.Drawing.Size(150, 153);
            this.wifi1.TabIndex = 45;
            this.wifi1.Load += new System.EventHandler(this.wifi1_Load);
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1029, 567);
            this.Controls.Add(this.guna2PictureBox12);
            this.Controls.Add(this.guna2PictureBox11);
            this.Controls.Add(this.guna2PictureBox10);
            this.Controls.Add(this.guna2PictureBox9);
            this.Controls.Add(this.guna2ShadowPanel3);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.m3);
            this.Controls.Add(this.garage1);
            this.Controls.Add(this.wifi1);
            this.Controls.Add(this.m4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.guna2ShadowPanel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "home";
            this.Text = "home";
            this.Load += new System.EventHandler(this.home_Load);
            this.guna2ShadowPanel2.ResumeLayout(false);
            this.guna2ShadowPanel2.PerformLayout();
            this.m4.ResumeLayout(false);
            this.m4.PerformLayout();
            this.m3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.guna2ShadowPanel1.ResumeLayout(false);
            this.guna2ShadowPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel2;
        private Guna.UI2.WinForms.Guna2VProgressBar guna2VProgressBar1;
        private Guna.UI2.WinForms.Guna2CircleProgressBar guna2CircleProgressBar2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2ImageRadioButton guna2ImageRadioButton6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label4;
        private MachineControlers.Wifi wifi1;
        private MachineControlers.Garage garage1;
        private Guna.UI2.WinForms.Guna2PictureBox cam;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch5;
        private System.Windows.Forms.Label cam_lab;
        private System.Windows.Forms.Label label16;
        private Guna.UI2.WinForms.Guna2ShadowPanel m4;
        private Guna.UI2.WinForms.Guna2ShadowPanel m3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch1;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox7;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel3;
        private Guna.UI2.WinForms.Guna2ToggleSwitch guna2ToggleSwitch3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox8;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox9;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox10;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox11;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox12;
    }
}